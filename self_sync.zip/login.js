// Ensure the script runs after the DOM is loaded
document.addEventListener("DOMContentLoaded", function () {
    // Get Modal Elements
    const modal = document.getElementById("loginModal");
    const openBtn = document.getElementById("openLogin");
    const closeBtn = document.querySelector(".close");

    // Ensure modal is hidden initially
    modal.style.display = "none";

    // Open Modal When Clicking Navbar Login Button
    if (openBtn) {
        openBtn.onclick = function (event) {
            event.preventDefault(); // Prevent default link behavior
            modal.style.display = "flex";
        };
    }

    // Close Modal When Clicking X Button
    if (closeBtn) {
        closeBtn.onclick = function () {
            modal.style.display = "none";
        };
    }

    // Close Modal When Clicking Outside the Box
    window.onclick = function (event) {
        if (event.target === modal) {
            modal.style.display = "none";
        }
    };
});
