const scroll = new LocomotiveScroll({
    el: document.querySelector('#main'),
    smooth: true
});

function circlemousefollower() {
    window.addEventListener("mousemove", function(dets) {
        document.querySelector("#mincircle").style.transform = 
            `translate(${dets.clientX}px, ${dets.clientY}px)`;
    });
}


if (typeof gsap !== 'undefined') {
    function firstpageanim() {
        var tl = gsap.timeline();  // Use gsap.timeline()

        // Animate navigation bar
        tl.from("#nav", {
            y: -10,   // Use number instead of string
            opacity: 0,
            duration: 1.5,
            ease: "expo.inOut"
        })
        .to(".boundingelem", {
            y: 0,
            ease: "expo.inOut",
            duration: 2,
            stagger: 0.2
        }, "-=1") // Delay using relative timing
        .from("#herofooter", {
            y: -10,
            opacity: 0,  // Fixed "opacity0" typo
            duration: 1.5,
            ease: "expo.inOut"
        }, "-=1");  // Relative timing for smoother animation
    }

    // Ensure animations run only after DOM loads
    document.addEventListener("DOMContentLoaded", function() {
        firstpageanim();
    });

} else {
    console.error("GSAP is not loaded. Make sure to include the GSAP library.");
}
circlemousefollower();